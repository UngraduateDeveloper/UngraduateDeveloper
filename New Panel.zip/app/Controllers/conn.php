<?php

$servername = "localhost";
$username = "id22074554_ungraduate";
$password = "Ungraduate@1234";
$dbname = "id22074554_ungraduate";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>